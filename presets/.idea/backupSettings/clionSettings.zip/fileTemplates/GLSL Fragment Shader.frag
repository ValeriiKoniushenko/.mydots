#version 460

void main() {
	gl_FragColor = vec4(1.0, 0.0, 0.0, 1.0);
}
